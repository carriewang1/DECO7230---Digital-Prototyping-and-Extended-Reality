// -----JS CODE-----
// @input SceneObject source
// @input SceneObject target



var update = script.createEvent("UpdateEvent");

update.bind(function()
{
    
script.target.getTransform().setWorldRotation(script.source.getTransform().getWorldRotation());
script.target.getTransform().setWorldPosition(script.source.getTransform().getWorldPosition());
   
})