// ParticleControllerHelper.js
// Version: 0.0.1
// Event: Lens Initialized
// Description: This helper script allows user to burst particles when onFound or onLost is called

// @input int particleAmount = 100
//@input Asset.Material particleMaterial

// @ui {"widget" : "separator"}
// @input bool printDebugLog

var mat = script.particleMaterial ? script.particleMaterial.mainPass : script.getSceneObject().getComponent("Component.MaterialMeshVisual").mainPass;

if (!mat) {
    debugPrint("ERROR: No particle material assigned in script", true);
    return;
}

var event = script.createEvent("UpdateEvent");
event.enabled = false;
event.bind(function(eventData) {
    mat.externalTimeInput += getDeltaTime();
});

function startParticles() {
    debugPrint(script.getSceneObject().name + " started");
    mat.externalTimeInput = 0;
    mat.externalSeed = Math.random();
    mat.spawnMaxParticles = script.particleAmount;
    event.enabled = true;
}

function stopParticles() {
    mat.externalTimeInput = 0;
    mat.spawnMaxParticles = 0;
    event.enabled = false;
}

function debugPrint(msg, force) {
    if (script.printDebugLog || force) {
        print("[ParticleControllerHelper], " + msg);
    }
}

script.api.startParticles = startParticles;
script.api.stopParticles = stopParticles;